/*
  Biplanes Revival
  Copyright (C) 2019-2023 Regular-dev community
  https://regular-dev.org
  regular.dev.org@gmail.com

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#include <include/ai_stuff.hpp>
#include <include/biplanes.hpp>
#include <include/controls.hpp>
#include <include/sdl.hpp>
#include <include/time.hpp>
#include <include/constants.hpp>
#include <include/game_state.hpp>
#include <include/menu.hpp>
#include <include/plane.hpp>
#include <include/bullet.hpp>
#include <include/render.hpp>
#include <include/utility.hpp>

#include <lib/SDL_Vector.h>
#include <lib/godot_math.hpp>

#include <cassert>
#include <iomanip>
#include <sstream>
#include <algorithm>


static bool
segment_intersects_polygon(
  const SDL_Vector& from,
  const SDL_Vector& to,
  const std::vector <SDL_Vector>& polygon,
  SDL_Vector* contact )
{
  const auto delta = to - from;

  if ( delta == SDL_Vector{} )
    return false;

  SDL_Vector closestContactPoint {from + delta * 2.f};

  for ( size_t i = 0, j = 1; j < polygon.size(); ++i, ++j )
  {
    SDL_Vector contactPoint {};

    const auto intersects = segment_intersects_segment(
      from, to,
      polygon.at(i), polygon.at(j),
      &contactPoint );

    if ( intersects == false )
      continue;

    if ( (contactPoint - from).length() < (closestContactPoint - from).length() )
      closestContactPoint = contactPoint;
  }

  const auto contactDistance =
    (closestContactPoint - from).length();

  if ( contactDistance > delta.length() )
    return false;


  if ( contact != nullptr )
    *contact = closestContactPoint;

  return true;
}

static float
get_distance_between_points(
  const SDL_Vector& p1,
  const SDL_Vector& p2 )
{
  return std::sqrt(
    std::pow( p2.x - p1.x, 2.f ) +
    std::pow( p2.y - p1.y, 2.f ) );
}

static float
get_angle_relative(
  const float angleSource,
  const float angleTarget )
{
  float relativeAngle = angleTarget - angleSource;

  if ( relativeAngle > 180.f )
    relativeAngle -= 360.f;
  else if ( relativeAngle < -180.f )
    relativeAngle += 360.f;

  return relativeAngle;
}

static float
get_angle_to_point(
  const SDL_Vector& source,
  const SDL_Vector& target )
{
  const SDL_Vector dir = target - source;

  float angle = std::atan2(dir.y, dir.x) + M_PI / 2.0;

  angle *= 180.f / M_PI;

  if ( angle < 0.f )
    angle += 360.f;

  return angle;
}


ContextMap::ContextMap(
  const size_t slotCount )
  : mValues(slotCount)
{
}

void
ContextMap::write(
  const size_t slot,
  const float value )
{
  assert(slot < mValues.size());

  mValues[slot] = value;
}

float&
ContextMap::operator [] (
  const size_t slot )
{
  assert(slot < mValues.size());

  return mValues[slot];
}

float
ContextMap::operator [] (
  const size_t slot ) const
{
  assert(slot < mValues.size());

  return mValues[slot];
}

void
ContextMap::reinit()
{
  std::fill(mValues.begin(), mValues.end(), 0.f);
}

void
ContextMap::normalize()
{
  const auto max = maxValue();

  for ( size_t i {}; i < mValues.size(); ++i )
    mValues[i] /= max;
}

size_t
ContextMap::size() const
{
  return mValues.size();
}

float
ContextMap::minValue() const
{
  assert(mValues.empty() == false);

  return *std::min_element(
    mValues.cbegin(),
    mValues.cend() );
}

float
ContextMap::maxValue() const
{
  assert(mValues.empty() == false);

  return *std::max_element(
    mValues.cbegin(),
    mValues.cend() );
}

size_t
ContextMap::minValueSlot() const
{
  assert(mValues.empty() == false);

  const auto lowestValueIter = std::min_element(
    mValues.cbegin(),
    mValues.cend() );

  return std::distance(
    mValues.cbegin(),
    lowestValueIter );
}

size_t
ContextMap::maxValueSlot() const
{
  assert(mValues.empty() == false);

  const auto highestValueIter = std::max_element(
    mValues.cbegin(),
    mValues.cend() );

  return std::distance(
    mValues.cbegin(),
    highestValueIter );
}

ContextMap
ContextMap::operator - (
  const ContextMap& other ) const
{
  assert(mValues.size() == other.mValues.size());

  ContextMap result {*this};

  for ( size_t i {}; i < mValues.size(); ++i )
    result.mValues[i] -= other.mValues[i];

  return result;
}

ContextMap
ContextMap::mask(
  const ContextMap& other,
  const float threshold ) const
{
  assert(mValues.empty() == false);
  assert(mValues.size() == mValues.size());

  ContextMap result {*this};

  for ( size_t i {}; i < mValues.size(); ++i )
    if ( other.mValues[i] > threshold )
      result.mValues[i] = {};

  return result;
}

float
ContextMap::sum(
  const size_t firstSlot,
  const size_t lastSlot,
  const int8_t dir ) const
{
  assert(dir != 0);
  assert(firstSlot < mValues.size());
  assert(lastSlot < mValues.size());

  float cost {};

  for ( size_t slot {firstSlot}; slot != lastSlot; )
  {
    cost += mValues[slot];

    if ( slot == 0 && dir < 0 )
      slot = mValues.size() - 1;

    else if ( slot == mValues.size() - 1 && dir > 0 )
      slot = 0;

    else
      slot += dir;
  }

  return cost;
}


AiTemperature::AiTemperature(
const Weights& sensitivity,
  const float value )
  : mValue {value}
  , mWeights{sensitivity}
{
}

void
AiTemperature::update(
  const float newValue,
  const float factor )
{
  const auto weight = newValue >= mValue
    ? mWeights.positive
    : mWeights.negative;

  const auto valueDiff = newValue - mValue;

//  TODO: epsilon comparison
  if ( std::abs(valueDiff) < 0.001f )
    return;

  mValue += factor * weight * std::copysign(1.f, valueDiff);
  mValue = std::clamp(mValue, 0.0f, 1.0f);
}

void
AiTemperature::set(
  const float newValue )
{
  mValue = newValue;
}

AiTemperature::operator float () const
{
  return mValue;
}

AiTemperature::Weights
AiTemperature::weights() const
{
  return mWeights;
}

AiTemperature::Weights
AiTemperature::Weights::FromTime(
  const float heatupTime,
  const float cooldownTime )
{
  return
  {
    1.f / heatupTime,
    1.f / cooldownTime,
  };
}


//class AiStateTakeoff : public AiState
//{
//public:
//  AiStateTakeoff( const AiTemperature& temperature );

//  void update(
//    const Plane& self,
//    const Plane& opponent,
//    const std::vector <Bullet>& opponentBullets ) override;

//  std::vector <AiAction> actions() const override;
//};


class AiStateTest : public AiState
{
public:
  AiStateTest( const AiTemperature& temperature );

  void update(
    const Plane& self,
    const Plane& opponent,
    const std::vector <Bullet>& opponentBullets ) override;

  std::vector <AiAction> actions() const override;
};

AiStateTest::AiStateTest(
  const AiTemperature& temperature )
  : AiState(temperature)
{
  mInterestMap = {constants::plane::directionCount};
  mDangerMap = {constants::plane::directionCount};

  constexpr auto ReactionTimeToWeights = &AiTemperature::Weights::FromTime;

  const auto throttleWeight = ReactionTimeToWeights(0.1f, 0.1f);
  const auto pitchWeight = ReactionTimeToWeights(0.1f, 0.1f);
  const auto shootWeight = ReactionTimeToWeights(0.04f, 0.04f);

  mActions =
  {
    {AiAction::Accelerate, throttleWeight},
    {AiAction::Decelerate, throttleWeight},
    {AiAction::TurnLeft, pitchWeight},
    {AiAction::TurnRight, pitchWeight},
    {AiAction::Shoot, shootWeight},
    {AiAction::Jump, {}},
  };
}

static bool
isPlaneStalling(
  const Plane& plane )
{
  namespace barn = constants::barn;
  namespace barn = constants::barn;

  const auto gravity = plane.maxSpeed() - plane.speed();

  SDL_Vector planeTrajectoryStart
  {
    plane.x(), plane.y(),
  };

  SDL_Vector planeTrajectoryEnd
  {
    plane.x(), plane.y() + gravity,
  };

  const SDL_Vector groundSegment[2]
  {
    {-10.f, constants::plane::groundCollision},
    {10.f, constants::plane::groundCollision},
  };

  SDL_Vector groundContactPoint {};

  const bool collidesWithGround = segment_intersects_segment(
    planeTrajectoryStart, planeTrajectoryEnd,
    groundSegment[0], groundSegment[1],
    &groundContactPoint );

  const std::vector <SDL_Vector> barnBox
  {
    {barn::planeCollisionX, constants::plane::groundCollision},
    {barn::planeCollisionX, barn::planeCollisionY},
    {barn::planeCollisionX + barn::sizeX, barn::planeCollisionY},
    {barn::planeCollisionX + barn::sizeX, constants::plane::groundCollision},
  };

  SDL_Vector barnContactPoint {};

  const bool collidesWithBarn = segment_intersects_polygon(
    planeTrajectoryStart, planeTrajectoryEnd,
    barnBox,
    &barnContactPoint );

  return collidesWithGround || collidesWithBarn;

  return plane.y() >= constants::plane::groundCollision - gravity;
}

static bool
isOpponentCloseBehind(
  const Plane& opponent,
  const float dirToOpponentRelative,
  const float shortestDistanceToOpponent )
{
  const auto opponentSpeedPercent =
    opponent.speed() / constants::plane::maxSpeedBoosted;

  return
    std::abs(dirToOpponentRelative) >= 45.f &&
    opponentSpeedPercent < 0.5f &&
    shortestDistanceToOpponent < 0.25f;
}

static bool
isAboutToCrash(
  const Plane& self )
{
  namespace plane = constants::plane;
  namespace pilot = constants::pilot;
  namespace barn = constants::barn;


  const auto dir = self.dir() * M_PI / 180.f;

  const auto speed = 0.5f * std::clamp(
    self.speed() * constants::tickRate,
    plane::maxSpeedBase,
    plane::maxSpeedBoosted );

  const SDL_Vector probeStart {self.x(), self.y()};

  const SDL_Vector probeEnd
  {
    probeStart.x + speed * std::sin(dir),
    probeStart.y - speed * std::cos(dir),
  };

  SDL_Vector closestContact {};

  const SDL_Vector groundSegment[2]
  {
    {-10.f, plane::groundCollision},
    {10.f, plane::groundCollision},
  };

  const bool collidesWithGround = segment_intersects_segment(
    probeStart, probeEnd,
    groundSegment[0], groundSegment[1],
    {} );

  if ( collidesWithGround == true )
    return true;


  const std::vector <SDL_Vector> barnBox
  {
    {barn::planeCollisionX, plane::groundCollision},
    {barn::planeCollisionX, barn::planeCollisionY},
    {barn::planeCollisionX + barn::sizeX, barn::planeCollisionY},
    {barn::planeCollisionX + barn::sizeX, plane::groundCollision},
  };

  const bool collidesWithBarn = segment_intersects_polygon(
    probeStart, probeEnd,
    barnBox, {} );

  return collidesWithBarn;
}

static bool
isSafeToJump(
  const Plane& self )
{
  namespace plane = constants::plane;
  namespace pilot = constants::pilot;

  const float jumpDir = self.jumpDir() * M_PI / 180.f;

  const SDL_Vector probeStart {self.x(), self.y()};

  const SDL_Vector probeEnd
  {
    probeStart.x,
    probeStart.y - 0.5f * pilot::ejectSpeed * std::cos(jumpDir),
  };


  const SDL_Vector groundSegment[2]
  {
    {-10.f, plane::groundCollision},
    {10.f, plane::groundCollision},
  };

  const bool collidesWithGround = segment_intersects_segment(
    probeStart, probeEnd,
    groundSegment[0], groundSegment[1],
    {} );

  return collidesWithGround == false;
}

void
AiStateTest::update(
  const Plane& self,
  const Plane& opponent,
  const std::vector <Bullet>& opponentBullets )
{
  namespace barn = constants::barn;
  namespace pilot = constants::pilot;
  namespace plane = constants::plane;

//  if ( self.type() == PLANE_TYPE::BLUE )
//  {
//    if ( isSafeToJump(self) == true )
//      log_message("safe\n");
//    else
//      log_message("unsafe\n");
//  }

  const float temperature = 1.f;

  mTemperature.update(temperature, deltaTime);

  mInterestMap.reinit();
  mDangerMap.reinit();

  const auto speed = 0.5f * std::clamp(
    self.speed() * constants::tickRate,
    plane::maxSpeedBase,
    plane::maxSpeedBoosted );


  for ( size_t i {}; i < plane::directionCount; ++i )
  {
    const auto dir = (i * plane::pitchStep) * M_PI / 180.f;

    const SDL_Vector probeStart {self.x(), self.y()};

    const SDL_Vector probeEnd
    {
      probeStart.x + speed * std::sin(dir),
      probeStart.y - speed * std::cos(dir),
    };

    {
      const SDL_Vector groundSegment[2]
      {
        {-10.f, plane::groundCollision},
        {10.f, plane::groundCollision},
      };

      SDL_Vector groundContactPoint {};

      const bool collidesWithGround = segment_intersects_segment(
        probeStart, probeEnd,
        groundSegment[0], groundSegment[1],
        &groundContactPoint );

      if ( collidesWithGround == true )
      {
        const float distance = (groundContactPoint - probeStart).length();

        const float danger = distance;

        mDangerMap.write(i, danger);
      }
    }

    {
      const std::vector <SDL_Vector> barnBox
      {
        {barn::planeCollisionX, plane::groundCollision},
        {barn::planeCollisionX, barn::planeCollisionY},
        {barn::planeCollisionX + barn::sizeX, barn::planeCollisionY},
        {barn::planeCollisionX + barn::sizeX, plane::groundCollision},
      };

      SDL_Vector barnContactPoint {};

      const bool collidesWithBarn = segment_intersects_polygon(
        probeStart, probeEnd,
        barnBox,
        &barnContactPoint );

      if ( collidesWithBarn == true )
      {
        const auto distance = (barnContactPoint - probeStart).length();

        const float danger = distance;

        if ( mDangerMap[i] > 0.f )
          mDangerMap.write(i, std::min(mDangerMap[i], danger));
        else
          mDangerMap.write(i, danger);
      }
    }
  }

  const auto closestBullets = bullets.GetClosestBullets(
    self.x(), self.y(), self.type() );

  for ( auto& bullet : closestBullets )
  {
    const SDL_Vector selfPathStart
    {
      self.x(),
      self.y(),
    };

    const SDL_Vector selfPathEnd
    {
      self.x() + self.speedVector().x,
      self.y() + self.speedVector().y,
    };

    const auto bulletDirLeft = (bullet.dir() - 90.f) * M_PI / 180.f;
    const auto bulletDirRight = (bullet.dir() + 90.f) * M_PI / 180.f;
    const auto bulletDir = bullet.dir() * M_PI / 180.f;

    const SDL_Vector bulletPathLeftStart
    {
      bullet.x() + plane::hitboxRadius * std::sin(bulletDirLeft),
      bullet.y() - plane::hitboxRadius * std::cos(bulletDirLeft),
    };

    const SDL_Vector bulletPathLeftEnd
    {
      bulletPathLeftStart.x + constants::bullet::speed * std::sin(bulletDir),
      bulletPathLeftStart.y - constants::bullet::speed * std::cos(bulletDir),
    };

    const SDL_Vector bulletPathRightStart
    {
      bullet.x() + plane::hitboxRadius * std::sin(bulletDirRight),
      bullet.y() - plane::hitboxRadius * std::cos(bulletDirRight),
    };

    const SDL_Vector bulletPathRightEnd
    {
      bulletPathRightStart.x + constants::bullet::speed * std::sin(bulletDir),
      bulletPathRightStart.y - constants::bullet::speed * std::cos(bulletDir),
    };

    SDL_Vector contactPoint {};

    bool willCollideWithBullet =
      segment_intersects_segment(
        selfPathStart, selfPathEnd,
        bulletPathLeftStart, bulletPathLeftEnd,
        &contactPoint );

    willCollideWithBullet |= segment_intersects_segment(
      selfPathStart, selfPathEnd,
      bulletPathRightStart, bulletPathRightEnd,
      &contactPoint );

    if ( willCollideWithBullet == false )
      continue;

    const auto dirToContactAbsolute = get_angle_to_point(
      selfPathStart, contactPoint );

    const auto distanceToContact = get_distance_between_points(
      selfPathStart, contactPoint );

    const size_t dirToContactIndex = std::round(
      dirToContactAbsolute / plane::pitchStep );

    const auto dirToContactClamped = dirToContactIndex % mDangerMap.size();

    mDangerMap[dirToContactClamped] = std::min(
      mDangerMap[dirToContactClamped],
      distanceToContact );
  }


  std::vector <AiAction> actions {};

  const SDL_Vector pos {self.x(), self.y()};
  const SDL_Vector opponentPos {opponent.pilot.x(), opponent.pilot.y()};

  const SDL_Vector opponentPosL = opponentPos - SDL_Vector{1.f, 0.f};
  const SDL_Vector opponentPosR = opponentPos + SDL_Vector{1.f, 0.f};

  const auto opponentDistance  = get_distance_between_points(pos, opponentPos);
  const auto opponentDistanceL = get_distance_between_points(pos, opponentPosL);
  const auto opponentDistanceR = get_distance_between_points(pos, opponentPosR);


  std::multimap <float, SDL_Vector> opponentPositionsSorted
  {
    {opponentDistance, opponentPos},
    {opponentDistanceL, opponentPosL},
    {opponentDistanceR, opponentPosR},
  };
  opponentPositionsSorted.erase(--opponentPositionsSorted.end());


  const auto [opponentShortestDistance, opponentShortestPos] =
    *opponentPositionsSorted.begin();

  const auto dirToOpponentAbsolute = get_angle_to_point(
    pos, opponentShortestPos );

  const auto dirToOpponentRelative = get_angle_relative(
    self.dir(), dirToOpponentAbsolute );

  const auto isOpponentBehind = isOpponentCloseBehind(
    opponent,
    dirToOpponentRelative,
    opponentShortestDistance );


  const bool isStalling = isPlaneStalling(self);

  if ( isOpponentBehind == true && isStalling == true )
    opponentPositionsSorted.erase(opponentPositionsSorted.begin());

  for ( const auto& [distance, position] : opponentPositionsSorted )
  {
    const auto dirToTargetAbsolute = get_angle_to_point(
      pos, position );

    const auto dirToTargetRelative = get_angle_relative(
      self.dir(), dirToTargetAbsolute );

    if (  std::abs(dirToTargetRelative) <= plane::pitchStep * 0.5f ||
          opponent.isHit(self.x(), self.y()) == true )
      actions.push_back(AiAction::Shoot);

    const auto dirL = std::floor(dirToTargetAbsolute / plane::pitchStep);
    const auto dirR = std::ceil(dirToTargetAbsolute / plane::pitchStep);

    const size_t dirIndex = std::round(dirToTargetAbsolute / plane::pitchStep);

    mInterestMap[dirIndex % mInterestMap.size()] = distance;
  }


  const auto maxDanger = SDL_Vector{plane::maxSpeedBoosted, plane::maxSpeedBoosted}.length();
  const auto maxInterest = SDL_Vector{2.f, pilot::groundCollision}.length();

  for ( size_t i {}; i < mDangerMap.size(); ++i )
  {
    auto& danger = mDangerMap[i];

    if ( danger != 0.f )
      danger = 1.f - danger / maxDanger;

    auto& interest = mInterestMap[i];

    if ( interest != 0.f )
      interest = 1.f - interest / maxInterest;
  }


  if ( isStalling == true )
  {
    mDangerMap[15] += 0.9f;
    mDangerMap[0] += 1.0f;
    mDangerMap[1] += 0.9f;
  }


  const auto opponentDistanceFactor = opponentShortestDistance / plane::maxSpeedBase;

  if ( opponentDistanceFactor < 1.f )
  {
    if ( std::abs(dirToOpponentRelative) >= 7.f * plane::pitchStep )
    {
      const auto dirToOpponentInverted = std::fmod(
        dirToOpponentAbsolute + 180.f, 360.f );

      const size_t dirToOpponentIndex = std::round(
        dirToOpponentAbsolute / plane::pitchStep );

      const size_t dirToOpponentInvertedIndex = std::round(
        dirToOpponentInverted / plane::pitchStep );

      mDangerMap[dirToOpponentIndex % mDangerMap.size()] +=
        0.5f * (1.f - opponentDistanceFactor);
      mDangerMap[dirToOpponentInvertedIndex % mDangerMap.size()] +=
        0.5f * (1.f - opponentDistanceFactor);
    }
  }


  const auto filteredMap = mInterestMap - mDangerMap;

  const size_t selfDirIndex = std::round(self.dir() / plane::pitchStep);

  const auto maxInterestSlot = filteredMap.maxValueSlot();

  const auto maxInterestDir = maxInterestSlot * plane::pitchStep;

  const auto interestOpponentDirDiff = get_angle_relative(
    maxInterestDir, dirToOpponentAbsolute );

  if ( selfDirIndex == maxInterestSlot )
  {
    const float threatThreshold {0.2f};

    if ( mDangerMap[selfDirIndex % mDangerMap.size()] > threatThreshold )
    {

    }

    if ( isStalling == true ||
         opponentShortestDistance > 0.25f ||
         self.speed() <= opponent.speed() ||
         std::abs(interestOpponentDirDiff) >= 45.f )
      actions.push_back(AiAction::Accelerate);
    else
      actions.push_back(AiAction::Decelerate);
  }
  else
  {
    std::multimap <float, size_t> sortedInterestDirs {};

    for ( size_t i {}; i < filteredMap.size(); ++i )
      sortedInterestDirs.insert({filteredMap[i], i});

    while ( sortedInterestDirs.size() > 2 )
      sortedInterestDirs.erase(sortedInterestDirs.begin());

    const auto pathStartLeft = std::clamp(selfDirIndex - 1ul, 0ul, mDangerMap.size() - 1ul);
    const auto pathStartRight = (selfDirIndex + 1) % mDangerMap.size();

    float lowestPathSumLeft {1000.f};
    float lowestPathSumRight {1000.f};

    for ( auto&& [interest, slot] : sortedInterestDirs )
    {
      if ( slot == selfDirIndex )
        continue;

      const auto pathSumLeft = mDangerMap.sum(pathStartLeft, slot, -1);
      const auto pathSumRight = mDangerMap.sum(pathStartRight, slot, +1);

      lowestPathSumLeft = std::min(lowestPathSumLeft, pathSumLeft);
      lowestPathSumRight = std::min(lowestPathSumRight, pathSumRight);
    }

    if ( std::abs(lowestPathSumLeft - lowestPathSumRight) < 0.1f )
    {
      const auto dirToInterestRelative = get_angle_relative(
        self.dir(),
        maxInterestSlot * plane::pitchStep );

      if ( dirToInterestRelative > 0 )
        actions.push_back(AiAction::TurnRight);
      else
        actions.push_back(AiAction::TurnLeft);
    }
    else if ( lowestPathSumLeft < lowestPathSumRight )
      actions.push_back(AiAction::TurnLeft);
    else if ( lowestPathSumLeft > lowestPathSumRight )
      actions.push_back(AiAction::TurnRight);


//    TODO: if relative dir >= 45 && distance < plane::sizeX
    if ( isOpponentBehind == false ||
         isStalling == true ||
         std::abs(interestOpponentDirDiff) >= 45.f )
      actions.push_back(AiAction::Accelerate);
    else
      actions.push_back(AiAction::Decelerate);
  }


  if ( self.hp() == 0 )
  {

  }


  std::sort(actions.begin(), actions.end());
  actions.erase(std::unique(actions.begin(), actions.end()), actions.end());

  for ( auto& [action, temperature] : mActions )
  {
    const bool actionFound = std::find(
      actions.cbegin(),
      actions.cend(),
      action ) != actions.cend();

    if ( actionFound == true )
      temperature.update(1.f, deltaTime);

    else
      temperature.update(0.f, deltaTime);
  }
}

std::vector <AiAction>
AiStateTest::actions() const
{
  const float threshold = 0.95f;

  std::vector <AiAction> actions {};

  for ( auto& [action, temperature] : mActions )
    if ( temperature >= threshold )
      actions.push_back(action);

  return actions;
}


void
AiController::init()
{
  for ( auto& [planeType, controller] : mStateController )
    controller.init();
}

void
AiController::update()
{
  for ( auto& [planeType, plane] : planes )
  {
//    if ( plane.isBot() == false )
//      continue;

    auto& stateController = mStateController.at(plane.type());

    if ( plane.isDead() == true )
    {
      stateController.init();
      continue;
    }


    const auto& opponentPlane =
      planes.at(static_cast <PLANE_TYPE> (!plane.type()));

    const auto opponentBullets = bullets.GetClosestBullets(
      plane.x(), plane.y(),
      plane.type() );

    stateController.update(
      plane, opponentPlane,
      opponentBullets );

    if ( plane.isBot() == false )
      continue;

    const auto aiState = stateController.currentState();

    const auto aiActions = aiState->actions();

    for ( const auto aiAction : aiActions )
      plane.input.ExecuteAiAction(aiAction);
  }
}

void
AiController::drawDebugLayer() const
{
  for ( auto& [planeType, plane] : planes )
  {
//    if ( plane.isBot() == false )
//      continue;

    auto& stateController = mStateController.at(plane.type());

    if ( plane.isDead() == false )
      stateController.drawDebugLayer(plane);
  }
}


void
AiStateController::init()
{
  mStates =
  {
    new AiStateTest({{}, 1.f}),
  };

  mCurrentState = mStates.back();
}

void
AiStateController::update(
  const Plane& self,
  const Plane& opponent,
  const std::vector <Bullet>& opponentBullets )
{
  assert(mStates.empty() == false);
  assert(mCurrentState != nullptr );


  for ( const auto state : mStates )
    state->update(
      self, opponent,
      opponentBullets );

  mCurrentState = *std::max_element(
    mStates.begin(), mStates.end(),
      [] ( const AiState* lhs, const AiState* rhs )
      {
        return lhs->temperature() < rhs->temperature();
      });
}

void
AiStateController::drawDebugLayer(
  const Plane& self ) const
{
  assert(mCurrentState != nullptr );

  mCurrentState->drawDebugLayer(self);
}

const AiState*
AiStateController::currentState() const
{
  return mCurrentState;
}


AiState::AiState(
const AiTemperature& temperature )
  : mTemperature{temperature}
{
}

void
AiState::update(
  const Plane& self,
  const Plane& opponent,
  const std::vector <Bullet>& opponentBullets )
{
  mTemperature.update(0.f);
}

std::vector <AiAction>
AiState::actions() const
{
  return {};
}

void
AiState::drawDebugLayer(
  const Plane& self ) const
{
  namespace plane = constants::plane;
  namespace aiDebug = constants::ai::debug;
  namespace aiColors = constants::colors::debug::ai;
  namespace collisionColors = constants::colors::debug::collisions;


  for ( size_t i {}; i < plane::directionCount; ++i )
  {
    const auto dir = (i * plane::pitchStep) * M_PI / 180.f;

    const SDL_Vector pos {self.x(), self.y()};

    {
      const SDL_Vector target
      {
        pos.x + aiDebug::dangerMagnitude * mDangerMap[i] * std::sin(dir),
        pos.y - aiDebug::dangerMagnitude * mDangerMap[i] * std::cos(dir),
      };

      setRenderColor(aiColors::danger);
      SDL_RenderDrawLine(
        gRenderer,
        toWindowSpaceX(self.x()) - 2,
        toWindowSpaceY(self.y()) - 2,
        toWindowSpaceX(target.x) - 2,
        toWindowSpaceY(target.y) - 2 );
    }

    {
      const SDL_Vector target
      {
        pos.x + aiDebug::interestMagnitude * mInterestMap[i] * std::sin(dir),
        pos.y - aiDebug::interestMagnitude * mInterestMap[i] * std::cos(dir),
      };

      setRenderColor(aiColors::interest);
      SDL_RenderDrawLine(
        gRenderer,
        toWindowSpaceX(self.x()) + 2,
        toWindowSpaceY(self.y()) + 2,
        toWindowSpaceX(target.x) + 2,
        toWindowSpaceY(target.y) + 2 );
    }

    {
      const auto heat = mInterestMap[i] - mDangerMap[i];

      if ( heat <= 0.f )
        continue;

      const SDL_Vector target
      {
        pos.x + aiDebug::heatMagnitude * heat * std::sin(dir),
        pos.y - aiDebug::heatMagnitude * heat * std::cos(dir),
      };

      setRenderColor(aiColors::seek);
      SDL_RenderDrawLine(
        gRenderer,
        toWindowSpaceX(self.x()),
        toWindowSpaceY(self.y()),
        toWindowSpaceX(target.x),
        toWindowSpaceY(target.y) );
    }
  }


  for ( auto& [action, temperature] : mActions )
  {
    SDL_FRect actionBox
    {
      aiDebug::actionGridOffsetX,
      aiDebug::actionGridOffsetY,
      aiDebug::actionBoxSizeX,
      aiDebug::actionBoxSizeY,
    };

    switch(action)
    {
      case AiAction::Accelerate:
      {
        actionBox.x += 1.f * aiDebug::actionBoxStepX;
        actionBox.y += 0.f * aiDebug::actionBoxStepY;

        break;
      }

      case AiAction::Decelerate:
      {
        actionBox.x += 1.f * aiDebug::actionBoxStepX;
        actionBox.y += 1.f * aiDebug::actionBoxStepY;

        break;
      }

      case AiAction::TurnLeft:
      {
          actionBox.x += 0.f * aiDebug::actionBoxStepX;
          actionBox.y += 1.f * aiDebug::actionBoxStepY;

          break;
      }

      case AiAction::TurnRight:
      {
          actionBox.x += 2.f * aiDebug::actionBoxStepX;
          actionBox.y += 1.f * aiDebug::actionBoxStepY;

          break;
      }

      case AiAction::Shoot:
      {
          actionBox.x += 2.f * aiDebug::actionBoxStepX;
          actionBox.y += 0.f * aiDebug::actionBoxStepY;

          break;
      }

      case AiAction::Jump:
      {
          actionBox.x += 0.f * aiDebug::actionBoxStepX;
          actionBox.y += 0.f * aiDebug::actionBoxStepY;

          break;
      }

      default:
        assert(false);
    }

    actionBox.x += self.pilot.x();
    actionBox.y += self.pilot.y();

    const auto actionGridRightBorder =
      self.pilot.x() + aiDebug::actionGridOffsetX + 3.f * aiDebug::actionBoxStepX;

    if ( actionGridRightBorder > 1.f )
      actionBox.x -= actionGridRightBorder - 1.f;

    const auto actionGridTopBorder =
      self.pilot.y() + aiDebug::actionGridOffsetY;

    if ( actionGridTopBorder < 0.f )
      actionBox.y -= actionGridTopBorder;

    actionBox =
    {
      toWindowSpaceX(actionBox.x),
      toWindowSpaceY(actionBox.y),
      scaleToScreenX(actionBox.w),
      scaleToScreenY(actionBox.h),
    };


    setRenderColor(aiColors::actionBox);
    SDL_RenderDrawRectF( gRenderer, &actionBox );


    if ( temperature <= 0.f )
      continue;

    SDL_BlendMode currentBlendMode {};
    SDL_GetRenderDrawBlendMode(
      gRenderer,
      &currentBlendMode );

    SDL_SetRenderDrawBlendMode(
      gRenderer,
      SDL_BLENDMODE_BLEND );

    auto actionBoxColor = aiColors::actionBox;
    actionBoxColor.a *= temperature;

    setRenderColor(actionBoxColor);
    SDL_RenderFillRectF( gRenderer, &actionBox );

    SDL_SetRenderDrawBlendMode(
      gRenderer,
      currentBlendMode );
  }


  if ( self.hasJumped() == true )
    return;

  namespace barn = constants::barn;

//  setRenderColor(aiColors::planeSpeedVector);
//  SDL_RenderDrawLine(
//    gRenderer,
//    toWindowSpaceX(self.x()) + 4,
//    toWindowSpaceY(self.y()) + 4,
//    toWindowSpaceX(self.x() + self.speedVector().x * constants::tickRate) + 4,
//    toWindowSpaceY(self.y() + self.speedVector().y * constants::tickRate) + 4 );

  const auto gravity = (self.maxSpeed() - self.speed());

  setRenderColor(aiColors::planeSpeedVector);
  SDL_RenderDrawLine(
    gRenderer,
    toWindowSpaceX(self.x()) + 4,
    toWindowSpaceY(self.y()) + 4,
    toWindowSpaceX(self.x()) + 4,
    toWindowSpaceY(self.y() + gravity) + 4 );

//  const std::vector <SDL_Vector> barnBox
//  {
//    {barn::planeCollisionX, plane::groundCollision},
//    {barn::planeCollisionX, barn::planeCollisionY},
//    {barn::planeCollisionX + barn::sizeX, barn::planeCollisionY},
//    {barn::planeCollisionX + barn::sizeX, plane::groundCollision},
//  };

//  const std::vector <SDL_Vector> groundBox
//  {
//    {-10.f, plane::groundCollision},
//    {10.f, plane::groundCollision},
//  };

//  const SDL_Vector pos {self.x(), self.y()};
//  const SDL_Vector speed
//  {
//    self.speedVector().x * constants::tickRate,
//    self.speedVector().y * constants::tickRate,
//  };

//  auto closestContact = pos + 2.f * speed;

//  {
//    auto closestBarnContact = closestContact;

//    segment_intersects_polygon(
//      pos,
//      speed,
//      barnBox,
//      &closestBarnContact );

//    if ( (closestBarnContact - pos).length() < (closestContact - pos).length() )
//      closestContact = closestBarnContact;
//  }

//  {
//    auto closestGroundContact = closestContact;

//    segment_intersects_polygon(
//      pos,
//      speed,
//      groundBox,
//      &closestGroundContact );

//    if ( (closestGroundContact - pos).length() < (closestContact - pos).length() )
//      closestContact = closestGroundContact;
//  }

//  if ( (closestContact - pos).length() < speed.length() )
//  {
//    closestContact.x = std::fmod(
//      std::fmod(closestContact.x, 1.f) + 1.f, 1.f );

//    const SDL_FRect contactPointRect
//    {
//      toWindowSpaceX(closestContact.x - 0.1f * plane::sizeX),
//      toWindowSpaceY(closestContact.y - 0.1f * plane::sizeY),
//      scaleToScreenX(0.2f * plane::sizeX),
//      scaleToScreenY(0.2f * plane::sizeY),
//    };

//    setRenderColor(aiColors::danger);
//    SDL_RenderFillRectF( gRenderer, &contactPointRect );
//  }
}

void
AiState::printActionTemperatures() const
{
  log_message("action temps: ");

  for ( auto& [action, temperature] : mActions )
  {
    const auto temperatureString = (std::stringstream {}
      << std::fixed
      << std::setprecision(2)
      << temperature).str();

    log_message(temperatureString + ", ");
  }

  log_message("\n");
}

void
AiState::setTemperature(
  const float newTemperature )
{
  mTemperature.set(newTemperature);
}

float
AiState::temperature() const
{
  return mTemperature;
}


float
calcBulletAvoidance(
  const Plane& self,
  const Plane& opponent )
{
//  TODO: calc danger
  const auto bulletDanger = 1.0f;

  const auto oppScore =
    static_cast <float> (opponent.score())
    / constants::defaultWinScore;

  const auto selfHp =
    gameState().isHardcoreEnabled == true
      ? 0.0f
      : static_cast <float> (self.hp()) /
        constants::plane::maxHp;


  const auto dangerFactor = 0.6f;
  const auto hpFactor = 0.3f;
  const auto scoreFactor = 0.1f;

  return
    bulletDanger * dangerFactor +
    (1.0f - selfHp) * hpFactor +
    oppScore * scoreFactor;
}

float
calcObstacleAvoidance(
  const Plane& self,
  const Plane& opponent )
{
//  TODO: calc danger
  const auto obstacleDanger = 1.0f;

  const auto selfScore =
    static_cast <float> (self.score())
    / constants::defaultWinScore;


  const auto dangerFactor = 0.8f;
  const auto scoreFactor = 0.2f;

  return
    obstacleDanger * dangerFactor +
    selfScore * scoreFactor;
}

float
calcClimbTemperature(
  const Plane& self,
  const Plane& opponent )
{
  namespace plane = constants::plane;

  if ( opponent.isDead() == false )
    return 0.0f;


  const auto altitude = 1.0f -
    self.y() /
    plane::groundCollision;

  const float protectionRemainder =
    opponent.protectionRemainder() /
    plane::spawnProtectionCooldown;


  const auto altitudeFactor = 0.4f;
  const auto protectionFactor = 0.6f;

  return
    altitude * altitudeFactor +
    protectionFactor * protectionRemainder;
}
